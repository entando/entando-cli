package com.mycompany.myapp.domain;

import static org.assertj.core.api.Assertions.assertThat;

import com.mycompany.myapp.web.rest.TestUtil;
import org.junit.jupiter.api.Test;

class AccConferenceTest {

    @Test
    void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(AccConference.class);
        AccConference accConference1 = new AccConference();
        accConference1.setId(1L);
        AccConference accConference2 = new AccConference();
        accConference2.setId(accConference1.getId());
        assertThat(accConference1).isEqualTo(accConference2);
        accConference2.setId(2L);
        assertThat(accConference1).isNotEqualTo(accConference2);
        accConference1.setId(null);
        assertThat(accConference1).isNotEqualTo(accConference2);
    }
}
