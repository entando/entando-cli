package com.mycompany.myapp.web.rest;

import com.mycompany.myapp.domain.AccConference;
import com.mycompany.myapp.repository.AccConferenceRepository;
import com.mycompany.myapp.web.rest.errors.BadRequestAlertException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import tech.jhipster.web.util.HeaderUtil;
import tech.jhipster.web.util.PaginationUtil;
import tech.jhipster.web.util.ResponseUtil;

/**
 * REST controller for managing {@link com.mycompany.myapp.domain.AccConference}.
 */
@RestController
@RequestMapping("/api")
@Transactional
public class AccConferenceResource {

    private final Logger log = LoggerFactory.getLogger(AccConferenceResource.class);

    private static final String ENTITY_NAME = "myBundleAccConference";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final AccConferenceRepository accConferenceRepository;

    public AccConferenceResource(AccConferenceRepository accConferenceRepository) {
        this.accConferenceRepository = accConferenceRepository;
    }

    /**
     * {@code POST  /acc-conferences} : Create a new accConference.
     *
     * @param accConference the accConference to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new accConference, or with status {@code 400 (Bad Request)} if the accConference has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/acc-conferences")
    public ResponseEntity<AccConference> createAccConference(@RequestBody AccConference accConference) throws URISyntaxException {
        log.debug("REST request to save AccConference : {}", accConference);
        if (accConference.getId() != null) {
            throw new BadRequestAlertException("A new accConference cannot already have an ID", ENTITY_NAME, "idexists");
        }
        AccConference result = accConferenceRepository.save(accConference);
        return ResponseEntity
            .created(new URI("/api/acc-conferences/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, true, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /acc-conferences/:id} : Updates an existing accConference.
     *
     * @param id the id of the accConference to save.
     * @param accConference the accConference to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated accConference,
     * or with status {@code 400 (Bad Request)} if the accConference is not valid,
     * or with status {@code 500 (Internal Server Error)} if the accConference couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/acc-conferences/{id}")
    public ResponseEntity<AccConference> updateAccConference(
        @PathVariable(value = "id", required = false) final Long id,
        @RequestBody AccConference accConference
    ) throws URISyntaxException {
        log.debug("REST request to update AccConference : {}, {}", id, accConference);
        if (accConference.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, accConference.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!accConferenceRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        AccConference result = accConferenceRepository.save(accConference);
        return ResponseEntity
            .ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, accConference.getId().toString()))
            .body(result);
    }

    /**
     * {@code PATCH  /acc-conferences/:id} : Partial updates given fields of an existing accConference, field will ignore if it is null
     *
     * @param id the id of the accConference to save.
     * @param accConference the accConference to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated accConference,
     * or with status {@code 400 (Bad Request)} if the accConference is not valid,
     * or with status {@code 404 (Not Found)} if the accConference is not found,
     * or with status {@code 500 (Internal Server Error)} if the accConference couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PatchMapping(value = "/acc-conferences/{id}", consumes = { "application/json", "application/merge-patch+json" })
    public ResponseEntity<AccConference> partialUpdateAccConference(
        @PathVariable(value = "id", required = false) final Long id,
        @RequestBody AccConference accConference
    ) throws URISyntaxException {
        log.debug("REST request to partial update AccConference partially : {}, {}", id, accConference);
        if (accConference.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, accConference.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!accConferenceRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        Optional<AccConference> result = accConferenceRepository
            .findById(accConference.getId())
            .map(existingAccConference -> {
                if (accConference.getName() != null) {
                    existingAccConference.setName(accConference.getName());
                }

                return existingAccConference;
            })
            .map(accConferenceRepository::save);

        return ResponseUtil.wrapOrNotFound(
            result,
            HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, accConference.getId().toString())
        );
    }

    /**
     * {@code GET  /acc-conferences} : get all the accConferences.
     *
     * @param pageable the pagination information.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of accConferences in body.
     */
    @GetMapping("/acc-conferences")
    public ResponseEntity<List<AccConference>> getAllAccConferences(Pageable pageable) {
        log.debug("REST request to get a page of AccConferences");
        Page<AccConference> page = accConferenceRepository.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(ServletUriComponentsBuilder.fromCurrentRequest(), page);
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * {@code GET  /acc-conferences/:id} : get the "id" accConference.
     *
     * @param id the id of the accConference to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the accConference, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/acc-conferences/{id}")
    public ResponseEntity<AccConference> getAccConference(@PathVariable Long id) {
        log.debug("REST request to get AccConference : {}", id);
        Optional<AccConference> accConference = accConferenceRepository.findById(id);
        return ResponseUtil.wrapOrNotFound(accConference);
    }

    /**
     * {@code DELETE  /acc-conferences/:id} : delete the "id" accConference.
     *
     * @param id the id of the accConference to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/acc-conferences/{id}")
    public ResponseEntity<Void> deleteAccConference(@PathVariable Long id) {
        log.debug("REST request to delete AccConference : {}", id);
        accConferenceRepository.deleteById(id);
        return ResponseEntity
            .noContent()
            .headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString()))
            .build();
    }
}
