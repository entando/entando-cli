package com.mycompany.myapp.repository;

import com.mycompany.myapp.domain.AccConference;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

/**
 * Spring Data SQL repository for the AccConference entity.
 */
@SuppressWarnings("unused")
@Repository
public interface AccConferenceRepository extends JpaRepository<AccConference, Long> {}
