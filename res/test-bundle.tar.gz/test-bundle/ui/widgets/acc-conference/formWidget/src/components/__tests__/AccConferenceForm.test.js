import React from 'react';
import '@testing-library/jest-dom/extend-expect';
import { fireEvent, render, wait } from '@testing-library/react';
import i18n from 'i18n/__mocks__/i18nMock';
import { accConferenceMockEdit as accConferenceMock } from 'components/__mocks__/accConferenceMocks';
import AccConferenceForm from 'components/AccConferenceForm';
import { createMuiTheme } from '@material-ui/core';
import { ThemeProvider } from '@material-ui/styles';

const theme = createMuiTheme();

describe('AccConference Form', () => {
  it('shows form', () => {
    const { getByLabelText, getByTestId } = render(
      <ThemeProvider theme={theme}>
        <AccConferenceForm accConference={accConferenceMock} />
      </ThemeProvider>
    );

    expect(getByTestId('accConference-id').value).toBe(accConferenceMock.id.toString());
    expect(getByLabelText('entities.accConference.name').value).toBe(accConferenceMock.name);
  });

  it('submits form', async () => {
    const handleSubmit = jest.fn();
    const { getByTestId } = render(
      <ThemeProvider theme={theme}>
        <AccConferenceForm accConference={accConferenceMock} onSubmit={handleSubmit} />
      </ThemeProvider>
    );

    const form = getByTestId('accConference-form');
    fireEvent.submit(form);

    await wait(() => {
      expect(handleSubmit).toHaveBeenCalledTimes(1);
    });
  });
});
