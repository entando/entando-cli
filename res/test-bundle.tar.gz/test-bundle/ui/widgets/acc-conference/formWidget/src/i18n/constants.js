export const DEFAULT_LOCALE = 'en'; // eslint-disable-line import/prefer-default-export
