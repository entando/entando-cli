import enLocale from 'date-fns/locale/en-US';

export default {
  en: enLocale,
};
