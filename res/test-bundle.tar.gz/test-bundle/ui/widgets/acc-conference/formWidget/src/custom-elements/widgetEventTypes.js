export const INPUT_EVENT_TYPES = {
  tableAdd: 'accConference.table.add',
  tableSelect: 'accConference.table.select',
};

export const OUTPUT_EVENT_TYPES = {
  create: 'accConference.form.create',
  update: 'accConference.form.update',
  errorCreate: 'accConference.form.errorCreate',
  errorUpdate: 'accConference.form.errorUpdate',
};

export const KEYCLOAK_EVENT_TYPE = 'keycloak';
