const customElementName = 'acc-conference-form';

export { customElementName };
