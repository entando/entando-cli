import { getDefaultOptions, request } from 'api/helpers';

const resource = 'api/acc-conferences';

export const apiAccConferenceGet = async (serviceUrl, id) => {
  const url = `${serviceUrl}/${resource}/${id}`;
  const options = {
    ...getDefaultOptions(),
    method: 'GET',
  };
  return request(url, options);
};

export const apiAccConferencePost = async (serviceUrl, accConference) => {
  const url = `${serviceUrl}/${resource}`;
  const options = {
    ...getDefaultOptions(),
    method: 'POST',
    body: accConference ? JSON.stringify(accConference) : null,
  };
  return request(url, options);
};

export const apiAccConferencePut = async (serviceUrl, id, accConference) => {
  const url = `${serviceUrl}/${resource}/${id}`;
  const options = {
    ...getDefaultOptions(),
    method: 'PUT',
    body: accConference ? JSON.stringify(accConference) : null,
  };
  return request(url, options);
};

export const apiAccConferenceDelete = async (serviceUrl, id) => {
  const url = `${serviceUrl}/${resource}/${id}`;
  const options = {
    ...getDefaultOptions(),
    method: 'DELETE',
  };
  return request(url, options);
};
