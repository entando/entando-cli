import { DEFAULT_LOCALE } from 'i18n/constants';
import { setYupLocale } from 'i18n/yup';
import { translateFn, setI18nextLocale } from 'i18n/i18next';

export default (locale) => {
  setI18nextLocale(locale, DEFAULT_LOCALE);
  setYupLocale(translateFn);
};
