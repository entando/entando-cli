INLINE_RUNTIME_CHUNK=false npm run build

pushd build/static/js

mv -f 2*.js vendor.accConference-form.js
mv -f main*.js main.accConference-form.js
mv -f runtime~main*.js runtime.accConference-form.js

popd

serve -l 5001 build
