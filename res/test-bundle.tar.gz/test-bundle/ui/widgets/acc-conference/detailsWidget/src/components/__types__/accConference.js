import PropTypes from 'prop-types';

const accConferenceType = PropTypes.shape({
  id: PropTypes.number,
  name: PropTypes.string,
});

export default accConferenceType;
