/* eslint-disable-next-line import/prefer-default-export */
export const DEFAULT_LOCALE = 'en';
