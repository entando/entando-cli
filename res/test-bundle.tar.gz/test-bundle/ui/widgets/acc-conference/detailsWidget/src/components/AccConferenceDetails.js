import React from 'react';
import PropTypes from 'prop-types';
import { withTranslation } from 'react-i18next';
import Box from '@material-ui/core/Box';

import accConferenceType from 'components/__types__/accConference';
import AccConferenceFieldTable from 'components/acc-conference-field-table/AccConferenceFieldTable';

const AccConferenceDetails = ({ t, accConference }) => {
  return (
    <Box>
      <h3 data-testid="details_title">
        {t('common.widgetName', {
          widgetNamePlaceholder: 'Acc Conference',
        })}
      </h3>
      <AccConferenceFieldTable accConference={accConference} />
    </Box>
  );
};

AccConferenceDetails.propTypes = {
  accConference: accConferenceType,
  t: PropTypes.func.isRequired,
};

AccConferenceDetails.defaultProps = {
  accConference: {},
};

export default withTranslation()(AccConferenceDetails);
