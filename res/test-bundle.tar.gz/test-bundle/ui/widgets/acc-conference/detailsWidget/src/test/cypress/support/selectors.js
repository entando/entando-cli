const customElementName = 'acc-conference-details';
const detailsTitle = '[data-testid=details_title]';
const entityIdCell = '[data-testid=accConferenceIdValue]';

export { customElementName, detailsTitle, entityIdCell };
