const accConferenceApiGetResponse = {
  id: -38,
  name:
    'Natus praesentium et est ea soluta. Fuga illo tempora distinctio quasi eum sint odit. Unde dolor aspernatur consequuntur. Molestiae excepturi eos voluptatem. Autem doloremque modi recusandae. Voluptatem corporis esse distinctio officia ut commodi qui.',
};

export default accConferenceApiGetResponse;
