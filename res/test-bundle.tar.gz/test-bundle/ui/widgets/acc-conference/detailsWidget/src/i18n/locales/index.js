import al from 'i18n/locales/al.json';

export default {
  al,
};
