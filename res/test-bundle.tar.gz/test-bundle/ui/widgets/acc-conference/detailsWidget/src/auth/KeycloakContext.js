import React from 'react';

const KeycloakContext = React.createContext(null);

export default KeycloakContext;
