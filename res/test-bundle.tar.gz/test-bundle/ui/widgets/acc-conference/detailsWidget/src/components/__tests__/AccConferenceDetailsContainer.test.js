import React from 'react';
import { render, wait } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';

import 'components/__mocks__/i18n';
import { apiAccConferenceGet } from 'api/accConference';
import accConferenceApiGetResponseMock from 'components/__mocks__/accConferenceMocks';
import AccConferenceDetailsContainer from 'components/AccConferenceDetailsContainer';

jest.mock('api/accConference');

jest.mock('auth/withKeycloak', () => {
  const withKeycloak = (Component) => {
    return (props) => (
      <Component
        {...props} // eslint-disable-line react/jsx-props-no-spreading
        keycloak={{
          initialized: true,
          authenticated: true,
        }}
      />
    );
  };

  return withKeycloak;
});

beforeEach(() => {
  apiAccConferenceGet.mockClear();
});

describe('AccConferenceDetailsContainer component', () => {
  test('requests data when component is mounted', async () => {
    apiAccConferenceGet.mockImplementation(() => Promise.resolve(accConferenceApiGetResponseMock));

    render(<AccConferenceDetailsContainer id="1" />);

    await wait(() => {
      expect(apiAccConferenceGet).toHaveBeenCalledTimes(1);
    });
  });

  test('data is shown after mount API call', async () => {
    apiAccConferenceGet.mockImplementation(() => Promise.resolve(accConferenceApiGetResponseMock));

    const { getByText } = render(<AccConferenceDetailsContainer id="1" />);

    await wait(() => {
      expect(apiAccConferenceGet).toHaveBeenCalledTimes(1);
      expect(getByText('entities.accConference.id')).toBeInTheDocument();
      expect(getByText('entities.accConference.name')).toBeInTheDocument();
    });
  });

  test('error is shown after failed API call', async () => {
    const onErrorMock = jest.fn();
    apiAccConferenceGet.mockImplementation(() => Promise.reject());

    const { getByText } = render(<AccConferenceDetailsContainer id="1" onError={onErrorMock} />);

    await wait(() => {
      expect(apiAccConferenceGet).toHaveBeenCalledTimes(1);
      expect(onErrorMock).toHaveBeenCalledTimes(1);
      expect(getByText('error.dataLoading')).toBeInTheDocument();
    });
  });
});
