// eslint-disable-next-line import/prefer-default-export
export const INPUT_EVENT_TYPES = {
  tableSelect: 'accConference.table.select',
};
export const OUTPUT_EVENT_TYPES = {
  error: 'accConference.details.error',
};
export const KEYCLOAK_EVENT_TYPE = 'keycloak';
