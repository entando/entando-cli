import PropTypes from 'prop-types';

const keycloakType = PropTypes.shape({
  initialized: PropTypes.bool,
  authenticated: PropTypes.bool,
});

export default keycloakType;
