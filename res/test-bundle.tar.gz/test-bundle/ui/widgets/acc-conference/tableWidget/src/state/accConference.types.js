export const READ_ALL = 'accConference-table/readAll';
export const ERROR_FETCH = 'accConference-table/error';
export const CLEAR_ERRORS = 'accConference-table/clearErrors';
export const CLEAR_ITEMS = 'accConference-table/clearItems';
export const CREATE = 'accConference-table/create';
export const UPDATE = 'accConference-table/update';
export const DELETE = 'accConference-table/delete';
