export const INPUT_EVENT_TYPES = {
  formUpdate: 'accConference.form.update',
  formCreate: 'accConference.form.create',
  formDelete: 'accConference.form.delete',
};

export const OUTPUT_EVENT_TYPES = {
  select: 'accConference.table.select',
  add: 'accConference.table.add',
  error: 'accConference.table.error',
  delete: 'accConference.table.delete',
};

export const KEYCLOAK_EVENT_TYPE = 'keycloak';
