export const ADD_FILTER = 'accConference-filter/addFilter';
export const UPDATE_FILTER = 'accConference-filter/updateFilter';
export const DELETE_FILTER = 'accConference-filter/deleteFilter';
export const CLEAR_FILTERS = 'accConference-filter/clearFilters';
