const accConferenceMocks = [
  {
    id: -38,
    name:
      'Natus praesentium et est ea soluta. Fuga illo tempora distinctio quasi eum sint odit. Unde dolor aspernatur consequuntur. Molestiae excepturi eos voluptatem. Autem doloremque modi recusandae. Voluptatem corporis esse distinctio officia ut commodi qui.',
  },
  {
    id: -679,
    name:
      'Laborum temporibus dolor recusandae libero enim dicta temporibus cum. Sed dolor corporis quod rerum perferendis illo esse. Facere aut dolores.',
  },
];

export default accConferenceMocks;
