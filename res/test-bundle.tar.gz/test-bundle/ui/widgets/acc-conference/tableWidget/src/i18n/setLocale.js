import { DEFAULT_LOCALE } from 'i18n/constants';
import { setI18nextLocale } from 'i18n/i18next';

export default (locale) => {
  setI18nextLocale(locale, DEFAULT_LOCALE);
};
