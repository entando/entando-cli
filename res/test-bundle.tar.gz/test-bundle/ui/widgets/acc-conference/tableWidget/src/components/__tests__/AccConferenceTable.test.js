import React from 'react';
import '@testing-library/jest-dom/extend-expect';
import { fireEvent, render } from '@testing-library/react';
import i18n from 'components/__mocks__/i18n';
import accConferenceMocks from 'components/__mocks__/accConferenceMocks';
import AccConferenceTable from 'components/AccConferenceTable';

describe('AccConferenceTable', () => {
  it('shows accConferences', () => {
    const { getByText } = render(<AccConferenceTable items={accConferenceMocks} />);

    expect(getByText(accConferenceMocks[0].id.toString())).toBeInTheDocument();
    expect(getByText(accConferenceMocks[1].id.toString())).toBeInTheDocument();

    expect(getByText(accConferenceMocks[0].name)).toBeInTheDocument();
    expect(getByText(accConferenceMocks[1].name)).toBeInTheDocument();
  });

  it('shows no accConferences message', () => {
    const { queryByText } = render(<AccConferenceTable items={[]} />);

    expect(queryByText(accConferenceMocks[0].id.toString())).not.toBeInTheDocument();
    expect(queryByText(accConferenceMocks[1].id.toString())).not.toBeInTheDocument();

    expect(queryByText(accConferenceMocks[0].name)).not.toBeInTheDocument();
    expect(queryByText(accConferenceMocks[1].name)).not.toBeInTheDocument();

    expect(queryByText('entities.accConference.noItems')).toBeInTheDocument();
  });

  it('calls onSelect when the user clicks a table row', () => {
    const onSelectMock = jest.fn();
    const { getByText } = render(
      <AccConferenceTable items={accConferenceMocks} onSelect={onSelectMock} />
    );

    fireEvent.click(getByText(accConferenceMocks[0].id.toString()));
    expect(onSelectMock).toHaveBeenCalledTimes(1);
  });
});
