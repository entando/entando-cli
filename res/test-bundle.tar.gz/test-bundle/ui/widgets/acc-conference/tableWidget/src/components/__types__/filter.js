import PropTypes from 'prop-types';

const filterType = PropTypes.shape({
  field: PropTypes.string,
  operator: PropTypes.string,
  value: PropTypes.string,
});

export default filterType;
