const customElementName = 'acc-conference-table';

export { customElementName };
